from django.contrib import admin
from django.urls import include, path
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('usuarios/', include('usuarios.urls')),
    path('usuarios/login/', auth_views.LoginView.as_view(), name='login'),
    path('admin/', admin.site.urls),
    path('comanda/', include('comanda.urls')),
    path('mesa/', include('mesa.urls')),
    path('item/', include('item.urls')),
    path('cardapio/', include('cardapio.urls')),
    path('pedido/', include('pedido.urls')),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
