from django.urls import re_path
from . import consumers

websocket_urlpatterns = [
    re_path(r'ws/pedido_status/$', consumers.PedidoStatusConsumer.as_asgi()),
]
