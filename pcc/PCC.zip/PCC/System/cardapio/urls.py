
from django.urls import path
from . import views


urlpatterns = [
    path('gerenciar/', views.gerenciar_cardapio, name='gerenciar_cardapio'),
    path('', views.visualizar_cardapio, name='visualizar_cardapio'),  # Visualizar o cardápio completo
    path('itens/', views.listar_itens, name='listar_itens'),  # Listar todos os itens
]
