# context_processors.py
def user_groups(request):
    return {
        'is_admin': request.user.is_authenticated and request.user.groups.filter(name='Administrador').exists()
    }
