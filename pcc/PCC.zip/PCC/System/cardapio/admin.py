from django.contrib import admin
from .models import Cardapio

admin.site.register(Cardapio)
