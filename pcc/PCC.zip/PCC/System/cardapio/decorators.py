# decorators.py
from django.http import HttpResponseForbidden

def grupo_admin_required(view_func):
    def _wrapped_view(request, *args, **kwargs):
        if request.user.is_authenticated and request.user.groups.filter(name='Administrador').exists():
            return view_func(request, *args, **kwargs)
        return HttpResponseForbidden("Você não tem permissão para acessar esta página.") #ja esta definido no html
    return _wrapped_view
