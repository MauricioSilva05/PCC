from django.shortcuts import  render
from .models import Item
from .decorators import grupo_admin_required



@grupo_admin_required
def gerenciar_cardapio(request):
    itens = Item.objects.all()
   
    return render(request, 'cardapio/gerenciar-cardapio.html', {'itens': itens})


def listar_itens(request):
    itens = Item.objects.all()
    itens_unicos = []
    # Dicionário para rastrear os nomes dos itens já adicionados
    nomes_adicionados = set()

    for item in itens:
        # Verifica se o nome do item já foi adicionado anteriormente
        if item.nome not in nomes_adicionados:
            itens_unicos.append(item)
            nomes_adicionados.add(item.nome)

    return render(request, 'listar_itens.html', {'itens': itens_unicos})

def visualizar_cardapio(request):
    # Verifica se o usuário está no grupo "Administrador"
    is_admin = request.user.groups.filter(name='Administrador').exists()
    
    context = {
        'is_admin': is_admin,
        'itens': Item.objects.all(),  # Supondo que você esteja passando uma lista de itens para o template
    }
    
    return render(request, 'cardapio/cardapio.html', context)





