// script.js
document.addEventListener("DOMContentLoaded", function() {
    const cartLink = document.getElementById("cartLink");
    const cart = document.getElementById("cart");
    const cartItems = document.getElementById("cartItems");
    const checkoutButton = document.getElementById("checkoutButton");

    // Simular itens do carrinho
    const items = [
        { name: "Produto 1", price: 29.99 },
        { name: "Produto 2", price: 49.99 },
        { name: "Produto 3", price: 19.99 },
    ];

    // Função para atualizar os itens do carrinho
    function updateCart() {
        cartItems.innerHTML = "";
        items.forEach(item => {
            const li = document.createElement("li");
            li.textContent = `${item.name} - R$ ${item.price.toFixed(2)}`;
            cartItems.appendChild(li);
        });
    }

    // Abrir e fechar o carrinho
    cartLink.addEventListener("click", function(event) {
        event.preventDefault();
        cart.classList.toggle("open");
    });

    // Atualizar os itens do carrinho ao carregar a página
    updateCart();

    // Exemplo de finalização de compra
    checkoutButton.addEventListener("click", function() {
        alert("Compra finalizada!");
    });
});
