toastr.options = {
  "positionClass": "toast-top-right",
  "timeOut": "3000",
};

// Carrega o som da notificação
const notificationSound = new Audio('/static/sounds/notificacao.mp3');

// Função para tocar o som da notificação
function playNotificationSound() {
  notificationSound.play();
}

// Função para obter o estado atual dos pedidos notificados do localStorage
function getPedidosNotificados() {
  const storedData = localStorage.getItem('pedidosNotificados');
  return storedData ? JSON.parse(storedData) : {};
}

// Função para salvar o estado dos pedidos notificados no localStorage
function savePedidosNotificados(pedidosNotificados) {
  localStorage.setItem('pedidosNotificados', JSON.stringify(pedidosNotificados));
}

function verificarStatusPedidos() {
  let pedidosNotificados = getPedidosNotificados();

  $.ajax({
      url: '/pedido/verificar-status-pedidos/',
      method: 'GET',
      success: function(data) {
          data.pedidos.forEach(function(pedido) {
              // Verifica se o pedido já foi notificado e se o status mudou
              if (!pedidosNotificados[pedido.id] || pedidosNotificados[pedido.id] !== pedido.status) {
                  // Atualiza o status do pedido no objeto de notificação
                  pedidosNotificados[pedido.id] = pedido.status;

                  // Exibe a notificação conforme o status
                  if (pedido.status === 'finalizado') {
                        toastr.success('Pedido ' + pedido.id + ' foi finalizado!');
                        playNotificationSound();  // Toca o som da notificação
                    }
                    
                  //if (pedido.status === 'em_preparo') {
                  //    toastr.info('Pedido ' + pedido.id + ' está em preparo!');
                  //    playNotificationSound();  // Toca o som da notificação
                //  } else if (pedido.status === 'finalizado') {
                  //    toastr.success('Pedido ' + pedido.id + ' foi finalizado!');
                  //    playNotificationSound();  // Toca o som da notificação
                //  }
              }
          });

          // Salva o estado atualizado dos pedidos notificados no localStorage
          savePedidosNotificados(pedidosNotificados);
      }
  });
}

// Função para obter o estado atual das comandas notificadas do localStorage
function getComandasNotificadas() {
  const storedData = localStorage.getItem('comandasNotificadas');
  return storedData ? JSON.parse(storedData) : {};
}

// Função para salvar o estado das comandas notificadas no localStorage
function saveComandasNotificadas(comandasNotificadas) {
  localStorage.setItem('comandasNotificadas', JSON.stringify(comandasNotificadas));
}

function verificarStatusComandas() {
  let comandasNotificadas = getComandasNotificadas();

  $.ajax({
      url: '/comanda/verificar-status-comandas/',
      method: 'GET',
      success: function(data) {
          data.comandas.forEach(function(comanda) {
              // Verifica se a comanda já foi notificada
              if (!comandasNotificadas[comanda.id]) {
                  // Atualiza o estado da comanda no objeto de notificação
                  comandasNotificadas[comanda.id] = true;

                  // Exibe a notificação
                  toastr.success('Comanda ' + comanda.id + ' foi finalizada!');
                  playNotificationSound();  // Toca o som da notificação
              }
          });

          // Salva o estado atualizado das comandas notificadas no localStorage
          saveComandasNotificadas(comandasNotificadas);
      }
  });
}

// Chama a função a cada 5 segundos (5000 milissegundos)
setInterval(verificarStatusPedidos, 5000);
setInterval(verificarStatusComandas, 5000);