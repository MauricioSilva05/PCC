from django.db import models

class Pedido(models.Model):
    comanda = models.ForeignKey('comanda.Comanda', on_delete=models.CASCADE, related_name='pedidos')  
    usuario = models.ForeignKey('usuarios.Usuario', on_delete=models.CASCADE)
    mesa = models.ForeignKey('mesa.Mesa', on_delete=models.CASCADE, null=True, blank=True)
    itens = models.ManyToManyField('item.Item', through="PedidoItem")  
    status = models.CharField(
        max_length=10, 
        choices=[('pendente', 'Pendente'), ('preparando', 'Preparando'), ('finalizado', 'Finalizado')],
        default='pendente'
    )
    data_hora = models.DateTimeField(auto_now_add=True)

    def get_total(self):
        total = 0
        for pedido_item in self.pedidoitem_set.all():
            total += pedido_item.item.preco * pedido_item.quantidade
        return total

    def __str__(self):
        return f"Pedido ID: {self.id} - Mesa: {self.mesa.numero if self.mesa else 'N/A'} - Usuário: {self.usuario.username}"

class PedidoItem(models.Model):
    pedido = models.ForeignKey(Pedido, on_delete=models.CASCADE)
    item = models.ForeignKey('item.Item', on_delete=models.CASCADE) 
    quantidade = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.quantidade}x {self.item.nome}"
