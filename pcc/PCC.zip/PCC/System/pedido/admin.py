from django.contrib import admin
from pedido.models import Pedido

class PedidoAdmin(admin.ModelAdmin):
    list_display = ('id', 'comanda', 'mesa', 'status', 'itens_pedidos')

    def comanda(self, obj):
        return obj.comanda
    comanda.short_description = 'Comanda'

    def itens_pedidos(self, obj):
        # Lista os itens associados ao pedido
        return f"{obj.item.nome} - {obj.quantidade_item}"
    itens_pedidos.short_description = 'Itens Pedidos'

admin.site.register(Pedido, PedidoAdmin)

