# pedido/urls.py
from django.urls import path
from . import views
from django.contrib.auth import views as auth_views 

urlpatterns = [
    path('gerenciar/', views.gerenciar_pedidos, name='gerenciar_pedidos'),
    path('pedidos/', views.listar_pedidos, name='listar_pedidos'),
    path('atualizar-status/<int:pedido_id>/', views.atualizar_status_pedido, name='atualizar_status_pedido'),
    path('finalizar-pedido/', views.finalizar_pedido, name='finalizar_pedido'),
    path('cancelar-pedido/<int:pedido_id>/', views.cancelar_pedido, name='cancelar_pedido'),
    path('verificar-status-pedidos/', views.verificar_status_pedidos, name='verificar_status_pedidos'),

]
