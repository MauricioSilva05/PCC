from django.shortcuts import redirect
from django.urls import reverse
import re

class CozinheiroRedirecionamentoMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated and request.user.groups.filter(name='Cozinheiro').exists():
            allowed_paths = [
                reverse('logout'),
                reverse('gerenciar_pedidos'),
                reverse('sair'),
                # Permitir o caminho de atualização de status com qualquer pedido_id
                 '/pedido/atualizar-status/', 
            ]

            if not any(re.fullmatch(path, request.path) if isinstance(path, re.Pattern) else request.path.startswith(path) for path in allowed_paths):
                return redirect('gerenciar_pedidos')

        response = self.get_response(request)
        return response
