# pedido/signals.py
from django.db.models.signals import post_save
from django.contrib.auth.models import User
from django.dispatch import receiver

@receiver(post_save, sender=User)
def adicionar_cozinheiro_grupo(sender, instance, created, **kwargs):
    if created and instance.groups.filter(name='Cozinheiro').exists():
        #Caso necessário, adicionar lógica específica quando um novo usuário é criado e adicionado ao grupo "Cozinheiro"
        pass
