def user_groups(request):
    return {
        'is_admin': request.user.is_authenticated and request.user.groups.filter(name='Administrador').exists(),
        'is_cozinheiro': request.user.is_authenticated and request.user.groups.filter(name='Cozinheiro').exists(),
        'is_garcom': request.user.is_authenticated and request.user.groups.filter(name='Garçom').exists(),
        'is_cliente': request.user.is_authenticated and request.user.groups.filter(name='Cliente').exists(),
    }
