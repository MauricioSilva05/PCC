from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from comanda.models import Comanda
from item.models import Item
from mesa.models import Mesa, Reserva
from usuarios.models import Usuario
from .models import Pedido, PedidoItem
from .decorators import grupo_required
from django.db.models import Sum, F
from django.http import JsonResponse
from django.template.loader import render_to_string
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET


@csrf_exempt
@login_required
@grupo_required('Cozinheiro', 'Administrador')
def atualizar_status_pedido(request, pedido_id):
    if request.method == 'POST':
        pedido = get_object_or_404(Pedido, id=pedido_id)
        novo_status = request.POST.get('status')
        
        if novo_status in ['pendente', 'preparo', 'finalizado']:
            pedido.status = novo_status
            pedido.save()

            return redirect('gerenciar_pedidos')
        else:
            print(f"Status inválido recebido: {novo_status}")  # Mensagem de depuração para status inválido
            

@login_required(login_url='/usuarios/login/')
def finalizar_pedido(request):
    if not request.user.is_authenticated:
        messages.warning(request, 'É necessário fazer login para realizar um pedido.')
        return redirect('usuarios:login')

    if request.method == 'POST':
        carrinho = request.session.get('carrinho', {})
        mesa_id = request.POST.get('mesa')

        if not carrinho:
            return redirect('visualizar_carrinho')

        mesa = get_object_or_404(Mesa, id=mesa_id) if mesa_id else None
        if not mesa:
            return redirect('visualizar_carrinho')

        # Obtém a instância do Usuario associada ao User
        usuario = get_object_or_404(Usuario, username=request.user.username)

        # Encontrar a comanda existente através dos pedidos
        pedidos = Pedido.objects.filter(usuario=usuario, status='pendente')

        if pedidos.exists():
            comanda = pedidos.first().comanda
            # Verifica se a comanda está finalizada
            if comanda.status == 'finalizada':
                # Se a comanda estiver finalizada, cria uma nova comanda
                comanda = Comanda.objects.create()
        else:
            # Se não houver pedidos pendentes, cria uma nova comanda
            comanda = Comanda.objects.create()

        # Cria um novo pedido
        pedido = Pedido.objects.create(
            comanda=comanda,
            mesa=mesa,
            usuario=usuario,  # Usa a instância do Usuario
            status='pendente'
        )

        reserva = Reserva.objects.filter(usuario=usuario).first()
        if reserva:
            pedido.reserva = reserva
            pedido.save()

        # Adiciona os itens ao pedido usando PedidoItem
        for item_id, item_info in carrinho.items():
            produto = get_object_or_404(Item, id=item_id)
            quantidade = item_info.get('quantidade', 1)

            # Cria o PedidoItem para cada item no carrinho
            PedidoItem.objects.create(
                pedido=pedido,
                item=produto,
                quantidade=quantidade
            )

        # Limpa o carrinho
        del request.session['carrinho']
        request.session.modified = True

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            return JsonResponse({'status': 'success', 'comanda_id': comanda.id})

        return redirect('visualizar_comanda', comanda_id=comanda.id)
    
def cancelar_pedido(request, pedido_id):
    pedido = get_object_or_404(Pedido, id=pedido_id)

    # Verifica se o usuário é do grupo 'Cozinheiro' e impede o cancelamento
    if request.user.groups.filter(name='Cozinheiro').exists():
        messages.error(request, 'Você não tem permissão para cancelar pedidos.')
        return redirect('listar_pedidos')

    if request.method == 'POST':
        if pedido.status == 'pendente':
            # Remove todos os itens associados ao pedido
            pedido_itens = PedidoItem.objects.filter(pedido=pedido)
            pedido_itens.delete()

            # Remove o pedido
            pedido.delete()

            # Obtém a comanda associada ao pedido
            comanda = pedido.comanda

            # Atualiza o total da comanda
            comanda_total = comanda.pedidos.aggregate(
                total=Sum(F('pedidoitem__quantidade') * F('pedidoitem__item__preco'))
            )['total'] or 0
            comanda.total = comanda_total
            comanda.save()

            # Verifica se ainda há pedidos associados à comanda
            if not comanda.pedidos.exists():
                # Se não houver mais pedidos associados à comanda, exclui a comanda
                comanda.delete()

            messages.success(request, 'Pedido cancelado com sucesso.')
        else:
            messages.error(request, 'Não é possível cancelar um pedido que não está pendente.')

    return redirect('listar_pedidos')


@login_required
@grupo_required('Cozinheiro', 'Administrador')
def gerenciar_pedidos(request):
    pedidos = Pedido.objects.prefetch_related('pedidoitem_set__item').order_by(
        'status',
        '-data_hora'
    )

    status_prioridade = {
        'pendente': 1,
        'preparo': 2,
        'finalizado': 3,
    }

    pedidos = sorted(pedidos, key=lambda p: status_prioridade.get(p.status, 0))

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        html_pedidos = render_to_string('pedido/_pedidos_lista.html', {'pedidos': pedidos})
        return JsonResponse({'html_pedidos': html_pedidos})

    return render(request, 'pedido/gerenciar-pedido.html', {
        'pedidos': pedidos,
    })


@login_required
def listar_pedidos(request):
    if request.user.groups.filter(name='Cliente').exists():
        pedidos = Pedido.objects.filter(usuario=request.user).order_by(
            'status',
            '-data_hora'
        )
    elif request.user.groups.filter(name__in=['Garçom', 'Administrador']).exists():
        pedidos = Pedido.objects.all().order_by(
            'status',
            '-data_hora'
        )
    else:
        pedidos = Pedido.objects.none()

    status_prioridade = {
        'finalizado': 1,
        'preparando': 2,
        'pendente': 3,
    }

    pedidos = sorted(pedidos, key=lambda p: status_prioridade.get(p.status, 0))

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        html_pedidos = render_to_string('pedido/_pedidos_lista_garcom.html', {'pedidos': pedidos})
        return JsonResponse({'html_pedidos': html_pedidos})

    return render(request, 'pedido/pedidos.html', {'pedidos': pedidos})



@require_GET
def verificar_status_pedidos(request):
    is_garcom_or_admin = request.user.groups.filter(name__in=['Garçom', 'Administrador']).exists()
    is_cliente = request.user.groups.filter(name='Cliente').exists()  # Verifica se o usuário é um cliente

    if is_garcom_or_admin:
        # Se o usuário é um garçom ou administrador, retorna todos os pedidos
        pedidos = Pedido.objects.all()
    elif is_cliente:
        # Se o usuário é um cliente, retorna apenas os pedidos feitos pelo usuário atual
        pedidos = Pedido.objects.filter(usuario=request.user)
    else:
        # Se o usuário não é nem garçom nem cliente, não exibe pedidos
        pedidos = Pedido.objects.none()

    # Formata os pedidos para JSON
    pedidos_data = [
        {
            'id': pedido.id,
            'status': pedido.status,
        }
        for pedido in pedidos]

    return JsonResponse({'pedidos': pedidos_data})


