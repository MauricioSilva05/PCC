from django.urls import path
from . import views

urlpatterns = [
    path('reservar/', views.reservar_mesa, name='reservar_mesa'),
    path('reservar/editar-reserva/<int:reserva_id>/', views.editar_reserva, name='editar_reserva'),
    path('reservar/excluir-reserva/<int:reserva_id>/', views.excluir_reserva, name='excluir_reserva'),
    path('listar-mesa/', views.listar_mesas, name='listar_mesas'),
    path('adicionar-mesa/', views.adicionar_mesa, name='adicionar_mesa'),
    path('editar-mesa/<int:mesa_id>/', views.editar_mesa, name='editar_mesa'),
    path('excluir-mesa/<int:mesa_id>/', views.excluir_mesa, name='excluir_mesa'),
    path('gerenciar-mesa/', views.gerenciar_mesa, name='gerenciar_mesa'),
    path('selecionar-mesa/', views.selecionar_mesa, name='selecionar_mesa'),
]

