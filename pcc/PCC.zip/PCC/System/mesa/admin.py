from django.contrib import admin
from .models import Mesa, Reserva

@admin.register(Mesa)
class MesaAdmin(admin.ModelAdmin):
    list_display = ('numero', 'status')

@admin.register(Reserva)
class ReservaAdmin(admin.ModelAdmin):
    list_display = ('mesa', 'quantidade_pessoas', 'data_reserva', 'usuario_nome', 'usuario_telefone', 'usuario_email')

    def usuario_nome(self, obj):
        """Retorna o nome do usuário associado à reserva."""
        return obj.usuario.nome
    usuario_nome.short_description = 'Nome do Usuário'

    def usuario_telefone(self, obj):
        """Retorna o telefone do usuário associado à reserva."""
        return obj.usuario.telefone
    usuario_telefone.short_description = 'Telefone do Usuário'

    def usuario_email(self, obj):
        """Retorna o email do usuário associado à reserva."""
        return obj.usuario.email
    usuario_email.short_description = 'Email do Usuário'
