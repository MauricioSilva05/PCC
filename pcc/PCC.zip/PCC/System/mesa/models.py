from django.db import models
from usuarios.models import Usuario

class Mesa(models.Model):

    CHOICES = [
        ('reservada', 'Esta mesa já está reservada'),
        ('não reservada', 'Esta mesa ainda não está reservada'),
    ]

    numero = models.CharField(max_length=3)
    status = models.CharField(max_length=128, choices=CHOICES, default='não reservada')

    def __str__(self):
        return self.numero

class Reserva(models.Model):
    mesa = models.ForeignKey(Mesa, on_delete=models.CASCADE)
    quantidade_pessoas = models.PositiveIntegerField()
    data_reserva = models.DateField()
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE)

    class Meta:
        unique_together = ['mesa','data_reserva']

    def __str__(self):
        return f'Reserva para a mesa {self.mesa.numero} por {self.usuario.username}'

    def detalhes_usuario(self):
        """Retorna o nome, telefone e email do usuário que fez a reserva."""
        return f'Nome: {self.usuario.username}, Telefone: {self.usuario.telefone}, Email: {self.usuario.email}'

