from pyexpat.errors import messages
from django.http import Http404, HttpResponseForbidden
from django.shortcuts import render, redirect,  get_object_or_404
from django.contrib.auth.decorators import login_required
from usuarios.models import Usuario
from .forms import ReservaMesaForm, MesaForm
from .models import Mesa, Reserva
from .decorators import grupo_admin_required

@login_required
def reservar_mesa(request):
    if request.method == 'POST':
        form = ReservaMesaForm(request.POST)
        if form.is_valid():
            reserva = form.save(commit=False)

            # Obter a instância do modelo Usuario associada ao usuário logado
            usuario = Usuario.objects.get(pk=request.user.id)  # Usando a chave primária
            reserva.usuario = usuario  # Associa a reserva ao usuário do modelo Usuario

            # Encontrar uma mesa não reservada
            mesa = Mesa.objects.filter(status='não reservada').first()
            if mesa:
                mesa.status = 'reservada'
                mesa.save()

                reserva.mesa = mesa
                reserva.save()

                return redirect('gerenciar_conta')  # Redireciona para a página de gerenciamento de conta
            else:
                form.add_error(None, 'Não há mesas disponíveis no momento.')
        else:
            print("Formulário inválido:", form.errors)
    else:
        form = ReservaMesaForm()

    # Pegar todas as reservas do usuário logado
    usuario = Usuario.objects.get(pk=request.user.id)  # Usando a chave primária
    reservas = Reserva.objects.filter(usuario=usuario)

    return render(request, 'mesa/reservar-mesa.html', {'form': form, 'reservas': reservas})


#CRUD de mesa
@grupo_admin_required
def gerenciar_mesa(request):
    mesa = Mesa.objects.all()
    return render(request, 'mesa/gerenciar-mesa.html', {'mesa': mesa})


def listar_mesas(request):
    mesa = Mesa.objects.all()
    return render(request, 'mesa/listar-mesas.html', {'mesa': mesa})

def adicionar_mesa(request):
    if request.method == 'POST':
        form = MesaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('gerenciar_mesa')
    else:
        form = MesaForm()
    return render(request, 'mesa/adicionar-mesa.html', {'form': form})


def editar_mesa(request, mesa_id):
    mesa = get_object_or_404(Mesa, pk=mesa_id)
    if request.method == 'POST':
        form = MesaForm(request.POST, instance=mesa)
        if form.is_valid():
            form.save()
            return redirect('gerenciar_mesa')
    else:
        form = MesaForm(instance=mesa)
    return render(request, 'mesa/editar-mesa.html', {'form': form, 'mesa': mesa})

def excluir_mesa(request, mesa_id):
    mesa = get_object_or_404(Mesa, pk=mesa_id)
    if request.method == 'POST':
        mesa.delete()
        return redirect('gerenciar_mesa')
    return render(request, 'mesa/excluir-mesa.html', {'mesa': mesa})

@login_required
def editar_reserva(request, reserva_id):
    reserva = get_object_or_404(Reserva, id=reserva_id)

    # Verifica se o usuário é o dono da reserva ou se é administrador
    if reserva.usuario == request.user or request.user.groups.filter(name='Administrador').exists():
        if request.method == 'POST':
            form = ReservaMesaForm(request.POST, instance=reserva)
            if form.is_valid():
                form.save()
                return redirect('gerenciar_conta')  # Redireciona para a página de gerenciamento de conta
        else:
            form = ReservaMesaForm(instance=reserva)
        
        return render(request, 'mesa/editar-reserva.html', {'form': form, 'reserva': reserva, 'reserva_id' : reserva_id})
    else:
        return HttpResponseForbidden("Você não tem permissão para editar esta reserva.")

@login_required
def excluir_reserva(request, reserva_id):
    reserva = get_object_or_404(Reserva, id=reserva_id)

    # Verifica se o usuário é o dono da reserva ou se é administrador
    if reserva.usuario == request.user or request.user.groups.filter(name='Administrador').exists():
        if request.method == 'POST':
            # Altera o status da mesa para 'não reservada'
            mesa = reserva.mesa
            mesa.status = 'não reservada'
            mesa.save()

            # Exclui a reserva
            reserva.delete()
            return redirect('gerenciar_conta')
        
        return render(request, 'mesa/excluir-reserva.html', {'reserva': reserva, 'reserva_id': reserva_id})
    else:
        return HttpResponseForbidden("Você não tem permissão para excluir esta reserva.")



def selecionar_mesa(request):
    if request.method == 'POST':
        mesa_id = request.POST.get('mesa')
        if mesa_id:
            mesa = get_object_or_404(Mesa, id=mesa_id)
            request.session['mesa_id'] = mesa.id
            messages.success(request, 'Mesa selecionada com sucesso.')
        else:
            messages.error(request, 'Selecione uma mesa válida.')
    return redirect('visualizar_carrinho')