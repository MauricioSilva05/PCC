from django.utils import timezone
from django import forms
from .models import Mesa, Reserva

class ReservaMesaForm(forms.ModelForm):
    class Meta:
        model = Reserva
        fields = ['quantidade_pessoas', 'data_reserva']
        widgets = {
            'data_reserva': forms.DateInput(
                attrs={'type': 'date'},
                format='%Y-%m-%d'
            )
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        today = timezone.now().date()
        self.fields['data_reserva'].widget.attrs['min'] = today



class MesaForm(forms.ModelForm):
    class Meta:
        model = Mesa
        fields = ['numero', 'status']


