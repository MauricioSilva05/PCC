# item/views.py

from django.shortcuts import render, redirect, get_object_or_404
from .models import Item
from .forms import ItemForm
from .decorators import grupo_admin_required


@grupo_admin_required
def adicionar_item(request):
    if request.method == 'POST':
        form = ItemForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('gerenciar_cardapio')  # Redirecione para a página que lista os itens do cardápio
    else:
        form = ItemForm()
    return render(request, 'cardapio/adicionar-item.html', {'form': form})


@grupo_admin_required
def editar_item(request, id):
    item = get_object_or_404(Item, id=id)
    if request.method == 'POST':
        form = ItemForm(request.POST, request.FILES, instance=item)
        if form.is_valid():
            form.save()
            return redirect('gerenciar_cardapio')  # Redirecione para a página que lista os itens do cardápio
    else:
        form = ItemForm(instance=item)
    return render(request, 'cardapio/editar-item.html', {'form': form})


@grupo_admin_required
def excluir_item(request, id):
    item = get_object_or_404(Item, id=id)
    if request.method == 'POST':
        item.delete()
        return redirect('gerenciar_cardapio')  # Redirecione para a página que lista os itens do cardápio
    return render(request, 'cardapio/excluir-item.html', {'item': item})
