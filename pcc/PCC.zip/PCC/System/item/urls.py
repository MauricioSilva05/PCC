# item/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('adicionar/', views.adicionar_item, name='adicionar_item'),
    path('editar/<int:id>/', views.editar_item, name='editar_item'),
    path('excluir/<int:id>/', views.excluir_item, name='excluir_item'),
]
