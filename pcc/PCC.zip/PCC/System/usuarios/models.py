from django.contrib.auth.models import User
from django.db import models
from django.core.validators import RegexValidator

class Usuario(User):
    cpf = models.CharField(max_length=14, unique=True, validators=[RegexValidator(regex='^.{14}$', message='CPF inválido')], verbose_name="Infome seu CPF")
    telefone = models.CharField(max_length=15, verbose_name="Telefone (99) 99999-9999", validators=[RegexValidator(regex='^.{15}$', message='CPF inválido')])
    data_nascimento = models.DateField(null=True, blank=True)

  


