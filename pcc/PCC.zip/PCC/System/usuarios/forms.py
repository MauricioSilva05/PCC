from django import forms
from django.contrib.auth.forms import UserChangeForm
from django.core.exceptions import ValidationError
from .models import Usuario
from datetime import date
import re

class UsuarioEditForm(UserChangeForm):
    class Meta:
        model = Usuario
        fields = ['username', 'email', 'cpf', 'telefone', 'data_nascimento']
        widgets = {
            'data_nascimento': forms.DateInput(attrs={'type': 'date'}),
        }

    def clean_data_nascimento(self):
        data_nascimento = self.cleaned_data['data_nascimento']
        today = date.today()
        age = today.year - data_nascimento.year - ((today.month, today.day) < (data_nascimento.month, data_nascimento.day))
        
        if age < 18:
            raise ValidationError("Você deve ter pelo menos 18 anos de idade.")
        
        return data_nascimento

class UsuarioForm(forms.ModelForm):

    username = forms.CharField(widget=forms.TextInput(attrs={"class": "username"}))
    
    password = forms.CharField(
        label='Senha',
        widget=forms.PasswordInput(attrs={
            'class': 'password',
        })
    )

    email = forms.EmailField(widget=forms.EmailInput(attrs={"class": "email"}))

    data_nascimento = forms.DateField(widget=forms.DateInput(attrs={"type": "date", "class": "data_nascimento"}))

    cpf = forms.CharField(
        widget=forms.TextInput(attrs={"class": "cpf", "maxlength": "14", 'placeholder': 'Digite seu CPF'}),
    )

    telefone = forms.CharField(
        widget=forms.TextInput(attrs={"class": "telefone", "maxlength": "15", 'placeholder': 'Formato: (38) 99208-4806'}),
    )

    class Meta:
        model = Usuario
        fields = ['username', 'password', 'email', 'cpf', 'telefone', 'data_nascimento']

    def _init_(self, *args, **kwargs):
        super()._init_(*args, **kwargs)
        self.fields['username'].label = 'Nome de Usuário'
        
    def clean_username(self):
        username = self.cleaned_data.get('username')
        if len(username) < 3:
            raise forms.ValidationError('Nome de usuário deve ter no mínimo 3 caracteres.')
        return username
    
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if '@' not in email:
            raise forms.ValidationError('Endereço de email inválido.')
        return email

    def clean_cpf(self):
        cpf = self.cleaned_data.get('cpf')
        if Usuario.objects.filter(cpf=cpf).exists():
            raise forms.ValidationError('Este CPF já está em uso.')
        return cpf

    def clean_telefone(self):
        telefone = self.cleaned_data.get('telefone')
        return telefone

    def clean_data_nascimento(self):
        data_nascimento = self.cleaned_data['data_nascimento']
        today = date.today()
        age = today.year - data_nascimento.year - ((today.month, today.day) < (data_nascimento.month, data_nascimento.day))
        
        if age < 18:
            raise ValidationError("Você deve ter pelo menos 18 anos de idade.")
        
        return data_nascimento