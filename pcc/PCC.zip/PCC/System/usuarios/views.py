from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from mesa.models import Mesa, Reserva
from pedido.models import Pedido
from .models import Usuario
from item.models import Item
from django.http import HttpResponseRedirect
from .forms import UsuarioEditForm, UsuarioForm
from .decorators import grupo_admin_required
from django.contrib.auth.models import Group
from django.http import HttpResponseForbidden
from django.contrib.auth import logout


def index(request):
    query = request.GET.get('q', '')  # Pega o parâmetro de busca
    if query:
        itens = Item.objects.filter(nome__icontains=query)  # Busca por itens cujo nome contenha a consulta
    else:
        itens = Item.objects.all()  # Exibe todos os itens se não houver consulta
    return render(request, '_base.html', {'itens': itens})

def gerenciar_conta(request):
    usuario = None
    reservas = []
    pedidos_info = []
    alert_message = None
    total_pedidos = 0

    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        new_group = request.POST.get('new_group')
        try:
            user = Usuario.objects.get(id=user_id)
            group = Group.objects.get(name=new_group)
            user.groups.set([group])
            user.save()
            return redirect('gerenciar_conta')
        except (Usuario.DoesNotExist, Group.DoesNotExist):
            return HttpResponseForbidden("Usuário ou grupo inválido.")

    if request.user.is_authenticated:
        if request.user.groups.filter(name='Administrador').exists():
            usuarios = Usuario.objects.exclude(is_superuser=True)
            grupos = Group.objects.all()
            reservas = Reserva.objects.all()  # Exibe todas as reservas para administradores
            is_admin = True
        else:
            try:
                usuario = Usuario.objects.get(username=request.user.username)
            except Usuario.DoesNotExist:
                usuario = None

            reservas = Reserva.objects.filter(usuario=request.user)  # Exibe apenas as reservas do próprio usuário
            pedidos = Pedido.objects.filter(usuario=request.user).exclude(status='cancelado')
            usuarios = [usuario] if usuario else []
            grupos = Group.objects.all()
            is_admin = False

            for pedido in pedidos:
                itens = pedido.pedidoitem_set.all()
                total_pedido = sum(pedido_item.item.preco * pedido_item.quantidade for pedido_item in itens)
                pedidos_info.append({
                    'pedido': pedido,
                    'itens': itens,
                    'total': total_pedido
                })
                total_pedidos += total_pedido  # Acumula o total de todos os pedidos

    else:
        usuarios = []
        grupos = []
        is_admin = False

    mesas_disponiveis = Mesa.objects.filter(status='não reservada').exists()

    return render(request, 'usuarios/gerenciar-conta.html', {
        'usuarios': usuarios,
        'grupos': grupos,
        'is_admin': is_admin,
        'user_authenticated': request.user.is_authenticated,
        'usuario': usuario,
        'reservas': reservas,
        'pedidos_info': pedidos_info,
        'alert_message': alert_message,
        'mesas_disponiveis': mesas_disponiveis,
        'total_pedidos': total_pedidos,  # Inclui o total acumulado no contexto
    })

# Criar CONTA
def criar_conta(request):
    if request.method == 'POST':
        form = UsuarioForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            
            # Cleaned(normalized) data
            password = form.cleaned_data['password']
            
            # Use set_password here
            user.set_password(password)
            user.save()

            # Adiciona o novo usuário ao grupo "Cliente"
            grupo_cliente, _ = Group.objects.get_or_create(name='Cliente')
            user.groups.add(grupo_cliente)

            return redirect('login')
    else:
        form = UsuarioForm()
    return render(request, "registration/criar-conta.html", {'form': form})


# Editar dados da CONTA
@login_required
def editar_dados(request, id_usuario):
    usuario = get_object_or_404(Usuario, id=id_usuario)
    if request.method == 'POST':
        form = UsuarioEditForm(request.POST, instance=usuario)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/usuarios/gerenciar-conta/?mensagem=Salvo')
    else:
        form = UsuarioForm(instance=usuario)
    return render(request, 'usuarios/editar-dados.html', {'form': form, 'id_usuario':id_usuario})

# Excluir CONTA
@login_required
def deletar_conta(request, id_usuario):
    Usuario.objects.get(pk=id_usuario).delete()
    if Usuario.objects.count() == 0:
        return HttpResponseRedirect("/usuarios/login?mensagem=Deletado")  # Redireciona para a página de login
    return HttpResponseRedirect("/usuarios/gerenciar-conta?msg=Deletado")


@login_required
def confirmar_exclusao_dados(request, id_usuario):
    # Recupere o objeto Usuario com base no id_usuario
    usuario = get_object_or_404(Usuario, pk=id_usuario)

    if request.method == 'POST':
        usuario.delete()
        return redirect('index.html')  # Ou qualquer URL para onde você deseja redirecionar após a exclusão

    return render(request, 'usuarios/confirmar-exclusao-dados.html', {'usuario': usuario})


def adicionar_ao_carrinho(request):
    if request.method == "POST":
        item_id = request.POST.get('item_id')
        quantidade = int(request.POST.get('quantidade', 1))  # Default to 1 if not provided
        item = Item.objects.get(id=item_id)
        comanda, created = comanda.objects.get_or_create(usuario=request.user, status='aberta')

        comanda.adicionar_item(item, quantidade)
        return redirect('nome_da_sua_view_ou_url')
    return redirect('nome_da_sua_view_ou_url')

#CRUD de itens

def sair(request):
    logout(request)
    return redirect('login')  # Redirecione para a página de login após o logout
