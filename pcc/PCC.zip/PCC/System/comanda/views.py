from django.shortcuts import get_object_or_404, redirect, render
from django.contrib import messages
from mesa.models import Mesa, Reserva
from pedido.models import Pedido
from item.models import Item
from comanda.models import Comanda
from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import render
from django.http import JsonResponse

def adicionar_ao_carrinho(request):
    if request.method == 'POST':
        item_id = request.POST.get('item_id')
        quantidade = int(request.POST.get('quantidade', 1))
        
        if quantidade <= 0:
            quantidade = 1

        item = get_object_or_404(Item, id=item_id)
        
        if 'carrinho' not in request.session:
            request.session['carrinho'] = {}
        
        carrinho = request.session['carrinho']
        if item_id in carrinho:
            carrinho[item_id]['quantidade'] += quantidade
        else:
            carrinho[item_id] = {
                'nome': item.nome,
                'quantidade': quantidade,
                'preco': str(item.preco)  # Armazena o preço como string
            }
        
        request.session.modified = True
        
    return redirect('visualizar_carrinho')



def visualizar_carrinho(request):
    carrinho = request.session.get('carrinho', {})
    
    itens_carrinho = [
        {
            'id': item_id,
            'nome': item['nome'],
            'quantidade': item['quantidade'],
            'preco': float(item['preco']),
            'total': float(item['preco']) * item['quantidade']
        }
        for item_id, item in carrinho.items()
    ]
    
    total_carrinho = sum(item['total'] for item in itens_carrinho)
    
    mesas_reservadas_ids = Reserva.objects.values_list('mesa_id', flat=True)
    mesas_disponiveis = Mesa.objects.exclude(id__in=mesas_reservadas_ids)
    
    contexto = {
        'itens_carrinho': itens_carrinho,
        'total_carrinho': total_carrinho,
        'mesas_disponiveis': mesas_disponiveis
    }
    
    return render(request, 'comanda/carrinho.html', contexto)



def remover_do_carrinho(request, item_id):
    # Converte item_id para string para garantir compatibilidade com as chaves do carrinho
    item_id = str(item_id)
    
    carrinho = request.session.get('carrinho', {})
    
    if item_id in carrinho:
        del carrinho[item_id]  # Remove o item do carrinho
        
        request.session['carrinho'] = carrinho
        request.session.modified = True
        
        messages.success(request, 'Item removido do carrinho com sucesso.')
    else:
        messages.error(request, 'Item não encontrado no carrinho.')
    
    return redirect('visualizar_carrinho')



def atualizar_quantidade(request, item_id):
    item_id = str(item_id)
    
    if request.method == 'POST':
        nova_quantidade = int(request.POST.get('quantidade', 1))
        
        if nova_quantidade <= 0:
            return redirect('visualizar_carrinho')

        carrinho = request.session.get('carrinho', {})
        
        if item_id in carrinho:
            carrinho[item_id]['quantidade'] = nova_quantidade
            
            request.session['carrinho'] = carrinho
            request.session.modified = True
            
            messages.success(request, 'Quantidade atualizada com sucesso.')
        else:
            messages.error(request, 'Item não encontrado no carrinho')
    
    return redirect('visualizar_carrinho')


from django.shortcuts import get_object_or_404, redirect
from django.contrib import messages
from .models import Comanda
from pedido.models import Pedido

def visualizar_comanda(request, comanda_id):
    # Obtém a comanda com base no ID
    comanda = get_object_or_404(Comanda, id=comanda_id)
    
    # Verifica se o usuário tem permissão para ver a comanda
    usuario_tem_acesso = Pedido.objects.filter(comanda=comanda, usuario=request.user).exists()
    
    if not usuario_tem_acesso and not request.user.groups.filter(name__in=['Garçom', 'Administrador']).exists():
        messages.error(request, "Você não tem permissão para visualizar esta comanda.")
        return redirect('listar_comanda')
    
    # Prepara as informações dos itens da comanda
    itens_comanda = []
    total_comanda = 0
    
    # Filtra apenas os pedidos não cancelados
    pedidos_ativos = Pedido.objects.filter(comanda=comanda).exclude(status='cancelado')
    
    # Obtém a mesa associada à comanda pelo primeiro pedido
    mesa = pedidos_ativos.first().mesa if pedidos_ativos.exists() else None
    
    for pedido in pedidos_ativos:
        for pedido_item in pedido.pedidoitem_set.all():
            item_info = {
                'nome': pedido_item.item.nome,
                'quantidade': pedido_item.quantidade,
                'preco': pedido_item.item.preco,
                'total': pedido_item.item.preco * pedido_item.quantidade
            }
            itens_comanda.append(item_info)
            total_comanda += item_info['total']

    contexto = {
        'comanda_info': {
            'comanda': comanda,
            'itens': itens_comanda,
            'total': total_comanda,
            'mesa': mesa,  # Acessa a mesa através do pedido
        }
    }

    return render(request, 'comanda/comanda.html', contexto)



@login_required
def listar_comanda(request):
    # Inicialize a variável 'comandas' com um valor padrão
    comandas = Comanda.objects.none()
    
    if request.user.groups.filter(name='Cliente').exists():
        # Para clientes, mostra apenas comandas associadas ao usuário por meio de pedidos
        comandas = Comanda.objects.filter(pedidos__usuario=request.user).distinct().order_by('-data_hora')
    elif request.user.groups.filter(name='Garçom').exists() or request.user.groups.filter(name='Administrador').exists():
        # Para garçons e administradores, mostra todas as comandas
        comandas = Comanda.objects.all().order_by('-data_hora')
    
    context = {
        'comandas': comandas
    }
    return render(request, 'comanda/listar-comanda.html', context)


from django.contrib.auth.models import Group

@login_required
def finalizar_comanda(request, comanda_id):
    if request.method == 'POST':
        comanda = get_object_or_404(Comanda, id=comanda_id)

        # Verifica se a comanda tem pelo menos um pedido
        pedidos = comanda.pedidos.all()
        if not pedidos.exists():
            messages.error(request, "Nenhum pedido encontrado para esta comanda.")
            return redirect('listar_comanda')

        # Verifica se o usuário é o dono dos pedidos ou pertence ao grupo 'garçom' ou 'administrador'
        if not (pedidos.filter(usuario=request.user).exists() or 
                request.user.groups.filter(name__in=['Garçom', 'Administrador']).exists()):
            messages.error(request, "Você não tem permissão para finalizar esta comanda.")
            return redirect('listar_comanda')

        if comanda.status == 'finalizada':
            messages.info(request, "Sua comanda já foi finalizada.")
            return redirect('index')

        comanda.status = 'finalizada'
        comanda.save()

        if 'carrinho' in request.session:
            del request.session['carrinho']
            request.session.modified = True

        messages.success(request, "A comanda foi finalizada com sucesso!")
        return redirect('listar_comanda')

    return redirect('visualizar_comanda', comanda_id=comanda_id)


@login_required
def verificar_status_comandas(request):
    # Verifica se o usuário faz parte do grupo Garçom ou Administrador
    is_garcom_or_admin = request.user.groups.filter(name__in=['Garçom', 'Administrador']).exists()

    if is_garcom_or_admin:
        # Se o usuário é Garçom ou Administrador, retorna todas as comandas finalizadas recentemente
        comandas = Comanda.objects.filter(status='finalizada')
    else:
        # Se o usuário não é Garçom nem Administrador, não retorna nada
        comandas = Comanda.objects.none()

    # Formata as comandas para JSON
    comandas_data = [
        {
            'id': comanda.id,
        }
        for comanda in comandas
    ]

    return JsonResponse({'comandas': comandas_data})

@login_required
@user_passes_test(lambda u: u.groups.filter(name='Administrador').exists())
def excluir_comanda(request, comanda_id):
    comanda = get_object_or_404(Comanda, id=comanda_id)
    comanda.delete()
    messages.success(request, 'Comanda excluída com sucesso.')
    return redirect('listar_comanda')
