from django.contrib import admin
from comanda.models import Comanda

class ComandaAdmin(admin.ModelAdmin):
    list_display = ('id', 'status', 'data_hora', 'total_da_comanda', 'get_mesas', 'get_usuarios')
    readonly_fields = ('total_da_comanda', 'get_mesas', 'get_usuarios')

    def total_da_comanda(self, obj):
        return f"R${obj.total():.2f}"
    total_da_comanda.short_description = 'Total da Comanda'

    def get_mesas(self, obj):
        return obj.get_mesas()
    get_mesas.short_description = 'Mesa(s)'

    def get_usuarios(self, obj):
        return obj.get_usuarios()
    get_usuarios.short_description = 'Usuário(s)'

admin.site.register(Comanda, ComandaAdmin)
