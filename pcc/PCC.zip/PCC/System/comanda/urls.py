from django.urls import path
from . import views

urlpatterns = [
    path('carrinho/', views.visualizar_carrinho, name='visualizar_carrinho'),
    path('carrinho/adicionar-ao-carrinho/', views.adicionar_ao_carrinho, name='adicionar_ao_carrinho'),
    path('carrinho/atualizar/<int:item_id>/', views.atualizar_quantidade, name='atualizar_quantidade'),
    path('carrinho/remover/<int:item_id>/', views.remover_do_carrinho, name='remover_do_carrinho'),
    path('comanda/<int:comanda_id>/', views.visualizar_comanda, name='visualizar_comanda'),
    path('comanda/finalizar/<int:comanda_id>/', views.finalizar_comanda, name='finalizar_comanda'),
    path('listar-comanda/', views.listar_comanda, name='listar_comanda'),
    path('verificar-status-comandas/', views.verificar_status_comandas, name='verificar_status_comandas'),
    path('excluir/<int:comanda_id>/', views.excluir_comanda, name='excluir_comanda'),

]
