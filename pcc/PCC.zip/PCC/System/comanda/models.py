from django.db import models

class Comanda(models.Model):
    STATUS_CHOICES = [
        ('aberta', 'Aberta'),
        ('finalizada', 'Finalizada'),
    ]
    
    data_hora = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='aberta')

    def adicionar_item(self, item, quantidade, mesa=None, usuario=None):
        """ Adiciona um item à comanda, criando ou atualizando um pedido. """
        from pedido.models import Pedido  # Importação dentro do método

        pedido, created = Pedido.objects.update_or_create(
            comanda=self,
            item=item,
            mesa=mesa,
            usuario=usuario,
            defaults={'quantidade': models.F('quantidade') + quantidade}
        )
        if created:
            pedido.quantidade = quantidade
            pedido.save()

    def total(self):
        """ Calcula o total da comanda. """
        from pedido.models import Pedido  # Importação dentro do método
        return sum(pedido.get_total() for pedido in Pedido.objects.filter(comanda=self))

    def get_mesas(self):
        """ Retorna uma lista de mesas associadas à comanda via pedidos. """
        from pedido.models import Pedido  # Importação dentro do método
        mesas = Pedido.objects.filter(comanda=self).values_list('mesa__numero', flat=True).distinct()
        return ', '.join([str(mesa) for mesa in mesas if mesa is not None])

    def get_usuarios(self):
        """ Retorna uma lista de usuários associados à comanda via pedidos. """
        from pedido.models import Pedido  # Importação dentro do método
        usuarios = Pedido.objects.filter(comanda=self).values_list('usuario__username', flat=True).distinct()
        return ', '.join(usuarios)

    def __str__(self):
        return f"Comanda ID: {self.id} - Mesas: {self.get_mesas()} - Usuários: {self.get_usuarios()}"
